// Файл: kubejs/startup_scripts/zoo_quests.js
// Работает с: KubeJS 6 + FTB Quests + FTB XMod Compat + rhino

ServerEvents.ftbquests(event => {
  console.info("[ZooQuests] Генерация квестов через FTB XMod Compat");

  const categories = {
    "Леса": {
      mobs: ["grizzly_bear", "capuchin_monkey"],
      icon: "minecraft:oak_leaves",
      bg: "minecraft:textures/block/oak_leaves.png"
    },
    "Саванны": {
      mobs: ["gazelle"],
      icon: "minecraft:acacia_sapling",
      bg: "minecraft:textures/block/acacia_log.png"
    },
    "Воды и побережья": {
      mobs: ["crocodile"],
      icon: "minecraft:water_bucket",
      bg: "minecraft:textures/block/water_still.png"
    },
    "Редкие и экзотические": {
      mobs: ["gorilla"],
      icon: "minecraft:end_crystal",
      bg: "minecraft:textures/block/end_stone.png"
    }
  };

  Object.entries(categories).forEach(([category, data], index) => {
    const chapter = event.chapter(`alex_mobs_${index}`)
      .title(`Alex's Mobs: ${category}`)
      .description(`Соберите животных из категории: ${category}`)
      .icon(data.icon)
      .defaultBackground(data.bg);

    data.mobs.forEach((mobId, idx) => {
      const name = mobId.split('_').map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(' ');

      chapter.task(`mob_${mobId}`)
        .title(name)
        .description(`Убейте ${name.toLowerCase()} и получите яйцо.`)
        .icon(`entity:alexsmobs:${mobId}`)
        .killEntity(`alexsmobs:${mobId}`)
        .rewardItem(`alexsmobs:${mobId}_spawn_egg`)
        .rewardXp(1395); // 1395 XP = уровень 30 в Minecraft
    });
  });

  console.info(`[ZooQuests] Сгенерировано ${Object.values(categories).map(c => c.mobs).flat().length} квестов по категориям`);
});
